export interface TopicMapping {
    topic: string;
    keywords: string[];
    priority: number;
}
export declare const serviceMappings: Record<string, TopicMapping[]>;
export declare const fallbackTopics: Record<string, string>;
//# sourceMappingURL=topic-mappings.d.ts.map