/**
 * Lambda function for topic tagging exam questions in DynamoDB
 *
 * Environment Variables:
 *   - DYNAMODB_TABLE_NAME: Name of the DynamoDB table (default: exam-questions)
 *   - DRY_RUN: Set to "false" to actually update DynamoDB (default: "true")
 *   - AWS_REGION: AWS region (default: us-east-1)
 *
 * This function scans all questions in DynamoDB and classifies them with topic tags
 * based on keyword matching against the question content.
 */
import { Handler } from "aws-lambda";
/**
 * Lambda handler entry point
 */
export declare const handler: Handler;
//# sourceMappingURL=index.d.ts.map